create database if not exists task;

use task;

Create Table Drivers_Schedule 
(
Drivers_Schedule_Id int not null, 
VehicleId int ,
RoutesId int , 
DriversId int,
PRIMARY KEY (Drivers_Schedule_Id),
FOREIGN   KEY (VehicleId) REFERENCES FleetOfVehicles(VehicleId),
FOREIGN   KEY (RoutesId) REFERENCES Group_Of_Routes(RoutesId),
FOREIGN   KEY (DriversId) REFERENCES Pool_Of_Drivers(DriversId)
)