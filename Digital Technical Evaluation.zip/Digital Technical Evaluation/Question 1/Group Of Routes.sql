create database if not exists task;

use task;
Create Table Group_Of_Routes 
(
RoutesId int not null, 

StartAddress nvarchar(200), 

EndAddress nvarchar (200), 

Distance nvarchar(50),

PRIMARY KEY (RoutesId)
)