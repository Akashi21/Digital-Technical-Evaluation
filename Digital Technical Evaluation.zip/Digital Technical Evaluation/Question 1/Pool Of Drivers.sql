create database if not exists task;

use task;
Create Table Pool_Of_Drivers
(
DriversId int not null,
DriversLicense  nvarchar(12),
Gender nvarchar(8), 
IDBook nvarchar (12),

 PRIMARY KEY (DriversId)
)