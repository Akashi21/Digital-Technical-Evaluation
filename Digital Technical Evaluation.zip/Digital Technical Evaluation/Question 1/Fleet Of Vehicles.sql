create database if not exists task;

use task;
Create  Table FleetOfVehicles
(
VehicleId int not null,

 Mileage int, 
 
 VinNUmbers nvarchar(50),
 
 Colour nvarchar(20),
 
 PRIMARY KEY (VehicleId)

)