create database if not exists task;

use task;
CREATE TABLE tUSER (
  id int AUTO_INCREMENT,
  id_number varchar(20) NOT NULL,
  first_names varchar(100) NOT NULL,
  last_name varchar(100) NOT NULL,
  PRIMARY KEY (id)
  
)