CREATE TABLE tTYPES (
  id int NOT NULL  AUTO_INCREMENT,
  type varchar(100) NOT NULL DEFAULT '',
  description varchar(255) NOT NULL,
 deleted TINYINT(1) NOT NULL DEFAULT '0',
 PRIMARY KEY (id)
)