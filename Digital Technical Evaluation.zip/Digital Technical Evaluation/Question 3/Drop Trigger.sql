create database if not exists task;

use task;
DROP TRIGGER IF EXISTS insertdata