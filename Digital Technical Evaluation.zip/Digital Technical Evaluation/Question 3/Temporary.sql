create database if not exists task;

use task;
Create Table temporary
(
record int not null,
id_number  nvarchar(20),
`first name` nvarchar(50),
`last name` nvarchar(50),
mssisdn nvarchar(15),
network nvarchar(20),
points int,
`card number` nvarchar(50),
Gender nvarchar(8), 

 PRIMARY KEY (record)
)