create database if not exists task;

use task;

DELIMITER $$
CREATE TRIGGER insertdata after INSERT ON temporary for each row

begin
set @id_number = new.id_number;
set @first_name = new.`first name`;
set @last_name = new.`last name`;
set @type = new.mssisdn;
set @description = new.network;
set  @tTYPES_id =0;
set  @tUser_id =0;

select  id into @tTYPES_id  from tTYPES where type=new.mssisdn ; 

select  id into @tUser_id  from tUser where id_number=new.id_number ;
set @value = new.`card number`;
Insert into tUser(id_number, first_names, last_name) values (@id_number,@first_name,@last_name);
Insert into tTypes(type, description) values(@type,@description);

insert into tprofile (tUser_id,tTYPES_id,value) values((SELECT id FROM tUSER ORDER BY id DESC LIMIT 1),(SELECT id FROM ttypes ORDER BY id DESC LIMIT 1),@value);
 end$$
  
  Delimiter  ;