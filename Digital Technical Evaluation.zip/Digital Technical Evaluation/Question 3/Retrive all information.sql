select p.value, u.id_number, u.first_names, u.last_name, t.type,t.description,t.deleted from tprofile p
inner join tuser u 
on u.id = p.tUSER_id
inner join ttypes t 
on t.id = p.tTYPES_ID