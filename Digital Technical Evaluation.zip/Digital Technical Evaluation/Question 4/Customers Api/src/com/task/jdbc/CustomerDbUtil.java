package com.task.jdbc;

import javax.sql.DataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.*;

public class CustomerDbUtil {
	
	private DataSource dataSource;
	
	public CustomerDbUtil (DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<Customer> getCustomer() throws Exception{
		
		List<Customer> customers = new ArrayList<>();
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			
			myConn = dataSource.getConnection();
			String sql = "select * from temporary order by record";
			myStmt = myConn.createStatement();
			myRs = myStmt.executeQuery(sql);
			
			while (myRs.next()) {
				int record = myRs.getInt("record");
				String id_number = myRs.getString("id_number");
				String firstName = myRs.getString("first name");
				String lastName = myRs.getString("last name");
				String mssisdn = myRs.getString("mssisdn");
				String network = myRs.getString("network");
				int points = myRs.getInt("points");
				String cardNumber = myRs.getString("card number");
				String gender = myRs.getString("gender");
				
				Customer tempCustomer = new Customer(record,id_number, firstName,lastName,mssisdn,network,points,cardNumber,gender);
				
				customers.add(tempCustomer);
			}
			
			return customers;
		}
		finally {
			close(myConn, myStmt,myRs);
		}
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs)  {
		
		try {
			
			if (myRs != null) {
				myRs.close();
			}
			
			if (myStmt != null) {
				myStmt.close();
			}
			
			if (myConn != null) {
				myConn.close();
			}
			
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
		
	}

	public void addCustomer(Customer customer) throws Exception {
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			myConn = dataSource.getConnection();
			String sql = "insert into temporary "+ "(record, id_number, `first name`, `last name`, mssisdn, network, points, `card number`, Gender) "
			+ "values (?,?,?,?,?,?,?,?,?)";
			
			myStmt = myConn.prepareStatement(sql);
			
			myStmt.setInt(1, customer.getRecord());
			myStmt.setString(2, customer.getId_number());
			myStmt.setString(3, customer.getFirst_name());
			myStmt.setString(4, customer.getLast_name());
			myStmt.setString(5, customer.getMssisdn());
			myStmt.setString(6, customer.getNetwork());
			myStmt.setInt(7, customer.getPoints());
			myStmt.setString(8, customer.getCard_number());
			myStmt.setString(9, customer.getGender());
			
			myStmt.execute();
		}
		
		finally {
			close(myConn, myStmt, null);
		}
	}

	public Customer getStudent(int record) throws Exception {
		// TODO Auto-generated method stub
		
		Customer theCustomer = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		int recordId;
		
		try {
			myConn = dataSource.getConnection();
			String sql = "select * from temporary where record=?";
			myStmt = myConn.prepareStatement(sql);
			myStmt.setInt(1, record);
			myRs = myStmt.executeQuery();
			
			if (myRs.next()) {
				String id_number = myRs.getString("id_number");
				String firstName = myRs.getString("first name");
				String lastName = myRs.getString("last name");
				String mssisdn = myRs.getString("mssisdn");
				String network = myRs.getString("network");
				int points = myRs.getInt("points");
				String cardNumber = myRs.getString("card number");
				String gender = myRs.getString("Gender");
				
				theCustomer = new Customer(record,id_number,firstName,lastName,mssisdn,network,points,cardNumber,gender);
			}
			else {
				throw new Exception ("could not find student record: "+record);
			}
			
			return theCustomer;
		}
		finally {
			close(myConn,myStmt,myRs);
		}
		
	
	}

	public void updateCustomer(Customer customer) throws Exception {
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		try {
			myConn = dataSource.getConnection();
			String sql = "update temporary " + "set id_number=?, `first name`=?, `last name`=?"+
			              ", mssisdn=?, network=?, points=?, `card number`=?,gender=? where record=?";
			myStmt = myConn.prepareStatement(sql);
			
			
			myStmt.setString(1,customer.getId_number());
			myStmt.setString(2,customer.getFirst_name());
			myStmt.setString(3,customer.getLast_name());
			myStmt.setString(4,customer.getMssisdn());
			myStmt.setString(5,customer.getNetwork());
			myStmt.setInt(6, customer.getPoints());
			myStmt.setString(7,customer.getCard_number());
			myStmt.setString(8,customer.getGender());
			myStmt.setInt(9, customer.getRecord());
			
			myStmt.execute();
			
		}
		finally {
			close(myConn, myStmt,null);
		}
	}

	public void deleteCustomer(int record) throws Exception {
		Connection myConn = null;
		PreparedStatement myStmt = null;
		try {
			myConn = dataSource.getConnection();
			
			String sql = "delete from temporary where record=?";
			
			myStmt = myConn.prepareStatement(sql);
			
			myStmt.setInt(1, record);
			
			myStmt.execute();
		}
		finally {
			close(myConn, myStmt,null);
		}
		
		
		
	}

	public List<Customer> getCustomers(String searchedData) throws Exception {
		List<Customer> customers = new ArrayList<>();
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			
			myConn = dataSource.getConnection();
			String sql = "select * from temporary where `first name` like '%"+ searchedData+"%'";
			
			myStmt = myConn.createStatement();
			
			myRs = myStmt.executeQuery(sql);
			
			while (myRs.next()) {
				int record = myRs.getInt("record");
				String id_number = myRs.getString("id_number");
				String firstName = myRs.getString("first name");
				String lastName = myRs.getString("last name");
				String mssisdn = myRs.getString("mssisdn");
				String network = myRs.getString("network");
				int points = myRs.getInt("points");
				String cardNumber = myRs.getString("card number");
				String gender = myRs.getString("gender");
				
				Customer customer = new Customer(record,id_number,firstName,lastName,mssisdn,network,points,cardNumber,gender);
				customers.add(customer);
			}
			return customers;
			
		}
		finally {
			close (myConn,myStmt, myRs);
		}
	
	}
	
	

}
