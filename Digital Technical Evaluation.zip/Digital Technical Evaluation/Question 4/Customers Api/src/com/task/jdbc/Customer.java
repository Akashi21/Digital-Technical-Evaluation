package com.task.jdbc;

public class Customer {
	
	private int record;
	private String id_number;
	private String first_name;
	private String last_name;
	private String mssisdn;
	private String network;
	private int points;
	private String card_number;
	private String gender;
	public Customer(int record, String id_number, String first_name, String last_name, String mssisdn, String network,
			int points, String card_number, String gender) {
		
		this.record = record;
		this.id_number = id_number;
		this.first_name = first_name;
		this.last_name = last_name;
		this.mssisdn = mssisdn;
		this.network = network;
		this.points = points;
		this.card_number = card_number;
		this.gender = gender;
	}
	public int getRecord() {
		return record;
	}
	public void setRecord(int record) {
		this.record = record;
	}
	public String getId_number() {
		return id_number;
	}
	public void setId_number(String id_number) {
		this.id_number = id_number;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getMssisdn() {
		return mssisdn;
	}
	public void setMssisdn(String mssisdn) {
		this.mssisdn = mssisdn;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public String getCard_number() {
		return card_number;
	}
	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	public String getGender() {
		return this.gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	
	

}
