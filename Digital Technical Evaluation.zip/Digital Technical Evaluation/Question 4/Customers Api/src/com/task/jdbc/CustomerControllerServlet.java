package com.task.jdbc;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;



/**
 * Servlet implementation class CustomerControllerServlet
 */
@WebServlet("/CustomerControllerServlet")
public class CustomerControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private CustomerDbUtil customerDbUtil;
	
	
	
	@Resource(name="jdbc/task")
	private DataSource dataSource;
	
	

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		
		try {
			customerDbUtil = new CustomerDbUtil(dataSource);
		}
		catch (Exception ex) {
			throw new ServletException(ex);
		}
	}



	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			String theCommand = request.getParameter("command");
			if (theCommand ==null) {
				theCommand ="LIST";
			}
			
			switch (theCommand) {
			case "LIST":
				listCustomer(request,response);
				break;
			case "ADD":
				addCustomer(request,response);
				break;
			case "LOAD":
				loadCustomer(request,response);
				break;
			case "UPDATE":
				updateCustomer(request,response);
				break;
			case "DELETE":
				deleteCustomer(request,response);
				break;
			case "SEARCH":
				SearchCustomer(request,response);
				break;
				
			default:
				listCustomer(request,response);
			}
			
		}
		catch (Exception exc) {
			// TODO Auto-generated catch block
			throw new ServletException(exc);
		}
	}



	private void SearchCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		String searchedData = request.getParameter("search");
		System.out.println(searchedData);
		listCustomers(request, response,searchedData);
	}



	private void listCustomers(HttpServletRequest request, HttpServletResponse response, String searchedData) throws Exception {
		List<Customer> customers;
		if (searchedData==null) {
		 customers = customerDbUtil.getCustomer();
		}else {
			customers = customerDbUtil.getCustomers(searchedData);
		}
		// add students to the request
		
		request.setAttribute("CUSTOMER_LIST", customers);
		
		// send to JSP page (view)
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-customers.jsp");
		
		dispatcher.forward(request, response);
		
		
	}



	private void deleteCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		int record = Integer.parseInt(request.getParameter("record"));
		customerDbUtil.deleteCustomer(record);
		
		listCustomer(request,response);
	}



	private void updateCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int record = Integer.parseInt(request.getParameter("record"));
		String id_number = request.getParameter("id_number");
		String FirstName = request.getParameter("firstName");
		String LastName = request.getParameter("lastName");
		String mssisdn = request.getParameter("mssisdn");
		String network = request.getParameter("network");
		int points = Integer.parseInt(request.getParameter("points"));
		String card_number = request.getParameter("card_number");
		String gender = request.getParameter("gender");
		
		Customer customer = new Customer(record,id_number,FirstName,LastName,mssisdn,network,points,card_number,gender);
		
		customerDbUtil.updateCustomer(customer);
		
		listCustomer(request,response);
		
	}



	private void loadCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int record = Integer.parseInt(request.getParameter("record"));
		Customer theCustomer = customerDbUtil.getStudent(record);
		
		request.setAttribute("THE_CUSTOMER", theCustomer);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/update-customer-form.jsp");
		dispatcher.forward(request, response);
		
	}



	private void addCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		int record = Integer.parseInt(request.getParameter("record")) ;
		String id_number = request.getParameter("id_number");
		String firstName = request.getParameter("first_name");
		String lastName = request.getParameter("last_name");
		String mssisdn = request.getParameter("mssisdn");
		String network = request.getParameter("network");
		int points =Integer.parseInt(request.getParameter("points")); 
		String card_number = request.getParameter("card_number");
		String gender = request.getParameter("gender");
		
		Customer customer = new Customer(record,id_number,firstName,lastName,mssisdn,network,points,card_number,gender);
		
		customerDbUtil.addCustomer(customer);
		
		listCustomer(request,response);
		
	}



	private void listCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<Customer> customers = customerDbUtil.getCustomer();
		
		request.setAttribute("CUSTOMER_LIST", customers);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-customers.jsp");
		
		dispatcher.forward(request, response);
		
	}

}
