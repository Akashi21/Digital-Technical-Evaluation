CREATE USER 'newuser'@'localhost' IDENTIFIED BY 'newuser';

GRANT ALL PRIVILEGES ON * . * TO 'newuser'@'localhost';
